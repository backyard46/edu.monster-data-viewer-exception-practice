﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MonsterDataViewer
{
    public partial class MonsterViewer : Form
    {

        private string serverName = "SIGMA-WSV009";
        private string databaseName = "kasai";
        private string userId = "kasai_admin";
        private string userPwd = "kasai_admin";

        public MonsterViewer()
        {
            InitializeComponent();
        }


        /// <summary>
        /// 閉じるボタン押下時処理。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonClose_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default["ServerName"] = serverName;
            Properties.Settings.Default["DatabaseName"] = databaseName;
            Properties.Settings.Default["UserID"] = userId;
            Properties.Settings.Default["Password"] = userPwd;

            Properties.Settings.Default.Save();

            this.Close();
        }


        /// <summary>
        /// 表示押下時処理。
        /// </summary>
        /// <remarks>
        /// TableAdapterを使ってパラメーターによる条件指定を用いたSQLでデータを取得。
        /// </remarks>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonShow_Click(object sender, EventArgs e)
        {
            // サーバー名： SIGMA-WSV009
            // データベース名： 各自の苗字ローマ字
            // ユーザーIDとパスワード： ローマ字苗字_admin


            //string serverName = "SIGMA-WSV009";
            //string databaseName = "kikuchi";
            //string userId = "kikuchi_admin";
            //string userPwd = "kikuchi_admin";

            monsterTblAdapter.Connection.ConnectionString = "Data Source="+serverName+";Initial Catalog="+databaseName+";User ID=" + userId +";Password=" + userPwd;


            // データ取得と表示
            try
            {
                if (textCondition.Text.Trim().Length == 0)
                {
                    // 検索条件なしの場合
                    monsterTblAdapter.Fill(monsterDataSet.Monsters);
                }
                else
                {
                    // 検索条件がある場合
                    monsterTblAdapter.FillByTypes(monsterDataSet.Monsters, textCondition.Text, textCondition.Text);
                }
            }
            catch (SqlException ex)
            {
                if (ex.InnerException == null)
                {
                    // サーバー名に誤りがある場合（この場合、どうやらInnerExceptionがnullになる）
                    MessageBox.Show("サーバー「" + serverName + "」に接続できません。\n\r接続先を再確認してください。", "接続失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (ex.Message.StartsWith("この"))
                {
                    // データベース名に誤りがある場合メッセージが「このログインで」で始まる
                    MessageBox.Show("データベース「" + serverName + "」に接続できません。\n\rデータベース名を再確認してください。", "接続失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    // その他 …… ログインIDかパスワードに誤りがある
                    MessageBox.Show("ユーザーIDまたはパスワードに誤りがあります。", "接続失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            gridMain.DataSource = monsterDataSet.Monsters;
            
        }


        /// <summary>
        /// クリアボタン押下時処理。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonClear_Click(object sender, EventArgs e)
        {
            gridMain.DataSource = null;
        }


        /// <summary>
        /// 接続先設定ボタン押下時処理。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonServerInfo_Click(object sender, EventArgs e)
        {
            ConnectionSettings child = new ConnectionSettings(serverName, databaseName, userId, userPwd);
            child.ShowDialog();

            serverName = child.ServerName;
            databaseName = child.DBName;
            userId = child.UserID;
            userPwd = child.Password;
            

        }

        private void MonsterViewer_Load(object sender, EventArgs e)
        {
            serverName=Properties.Settings.Default["ServerName"].ToString();
            databaseName=Properties.Settings.Default["DatabaseName"].ToString();
            userId=Properties.Settings.Default["UserID"].ToString();
            userPwd=Properties.Settings.Default["Password"].ToString();

        }


    }
}
