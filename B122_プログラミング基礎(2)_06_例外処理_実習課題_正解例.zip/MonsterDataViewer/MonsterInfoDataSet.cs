﻿namespace MonsterDataViewer {
    
    
    public partial class MonsterInfoDataSet {
        partial class MonstersDataTable
        {
        }
    }
}


namespace MonsterDataViewer.MonsterInfoDataSetTableAdapters {
    
    
    public partial class MonstersTableAdapter {
    }
}
